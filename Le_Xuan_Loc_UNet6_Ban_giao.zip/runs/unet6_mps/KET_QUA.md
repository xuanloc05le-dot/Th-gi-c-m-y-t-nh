# Kết quả thực nghiệm U-Net 6 kênh — Lê Xuân Lộc (23001533)

Các số liệu dưới đây được đọc từ tệp kết quả thực nghiệm thực tế.

- Dữ liệu train/validation: 552/118 cặp.
- Tập test: 118 cặp; đánh giá theo pixel ở độ phân giải mask gốc.
- Thiết bị: mps; PyTorch 2.2.2.
- Thiết bị đánh giá: cpu.
- Đầu vào: 6×512×512; U-Net base=16.
- Batch size: 4; AdamW, learning rate ban đầu 0.001.
- Loss: cross entropy; trọng số lớp: [0.08493351191282272, 0.7758607268333435, 1.2396818399429321, 1.1407207250595093, 1.7588030099868774].
- Số epoch đã chạy: 20/20; checkpoint được chọn ở epoch 20.
- Tiêu chí chọn checkpoint: mIoU bốn lớp thiệt hại trên validation.
- Tổng thời gian các epoch: 55.6 phút.
- SHA-256 manifest: `2523f024c0871a278f2b20c085f156b2c5492391c780cb92bd41dc03380c6a71`.

| Lớp | IoU | Dice/F1 | Số pixel ground truth |
|---|---:|---:|---:|
| Nền | 98.21% | 99.10% | 30,095,472 |
| Không hư hại | 27.40% | 43.01% | 345,038 |
| Hư hại nhẹ | 0.07% | 0.14% | 198,037 |
| Hư hại nặng | 23.98% | 38.69% | 205,035 |
| Phá hủy | 1.29% | 2.54% | 89,410 |
| Macro 5 lớp | 30.19% | 36.70% | — |
| Macro 4 lớp thiệt hại | 13.19% | 21.10% | — |

Đây là chỉ số phân đoạn theo pixel, không phải độ chính xác phân loại từng công trình. Lớp vắng ở cả ground truth và dự đoán bị loại khỏi macro; dự đoán sai vào lớp vắng vẫn được tính là lỗi.

Dữ liệu hiện tại thuộc HURRICANE-IRMA. Bộ chia ngẫu nhiên theo cặp ảnh không chứng minh độc lập không gian hoặc khả năng tổng quát hóa sang sự kiện mới. Cần đọc kết quả từng lớp, đặc biệt các lớp thiệt hại hiếm, trước khi kết luận chất lượng.

Ảnh so sánh nằm trong `test/*_comparison.png`; biểu đồ huấn luyện là `learning_curves.png`; confusion matrix là `test/confusion_matrix.png`. Mô hình bàn giao: `best.pt`.

## Nhận xét từ số liệu

Trong bốn lớp thiệt hại, IoU cao nhất thuộc lớp Không hư hại (27.40%), thấp nhất thuộc lớp Hư hại nhẹ (0.07%).

Khi gộp các nhãn 1–4 thành vùng công trình, IoU đạt 54.06% và Dice đạt 70.18%. Đây là đánh giá vị trí công trình suy ra từ mask 5 lớp; nhầm giữa hai mức thiệt hại vẫn được tính là đúng vùng công trình trong phép đánh giá nhị phân này.

Tỷ lệ pixel công trình trong ground truth bị dự đoán thành nền là 23.96%. Để phân tích nhầm mức thiệt hại, đọc các ô ngoài đường chéo trong confusion matrix và đối chiếu ảnh minh họa.
